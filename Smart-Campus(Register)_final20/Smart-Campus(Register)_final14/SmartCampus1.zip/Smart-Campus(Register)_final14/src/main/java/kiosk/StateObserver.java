/*
 * Copyright (c) 2020 Self-Order Kiosk
 */
package kiosk;

public interface StateObserver {

  public void onStateChange();

}

/*
 * Copyright (c) 2020 Self-Order Kiosk
 */
package kiosk;

public interface StateObservable {

  public void addObserver(StateObserver observer);

}
